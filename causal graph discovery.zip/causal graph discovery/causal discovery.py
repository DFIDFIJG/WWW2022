import os
from castle.common import GraphDAG
# from castle.metrics import MetricsDAG
# from castle.datasets import DAG, IIDSimulation
from castle.algorithms import CORL2

import numpy as np

p="region_features_NYC.csv"
with open(p,encoding = 'utf-8') as f:
    inputdata = np.loadtxt(f,delimiter = ",", skiprows = 1)
inputdata=inputdata[:,1:]
max_ = np.max(inputdata, axis = 0)
min_ = np.min(inputdata, axis = 0)
inputdata = (inputdata - min_) * 2 / (max_ - min_) -1
# rl learn
rl = CORL2(nb_epoch=2000)
rl.learn(inputdata)

# plot est_dag and true_dag

np.savetxt('best_graph_DAWG_NYC.txt', rl.causal_matrix)





